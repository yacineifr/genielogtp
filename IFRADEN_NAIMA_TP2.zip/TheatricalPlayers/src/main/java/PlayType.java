public enum PlayType {

    TRAGEDY, COMEDY, HISTORY, PASTORAL;
}
